function Home() {
    return ( 
        <h2>Home page</h2>
     );
}

export default Home;